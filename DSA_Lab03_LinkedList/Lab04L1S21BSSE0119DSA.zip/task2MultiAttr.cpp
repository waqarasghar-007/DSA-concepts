#include <iostream>
#include <string>
using namespace std;

class Node
{
private:
	Node* next;
	Node* previous;
	int data; //unique ID
	string name;
	string address;
public:
	Node()
	{
		next = NULL;
		previous = NULL;
		data = 0;
		name = address = nullptr;
	}
	Node(int data,string name, string address)
	{
		this->data = data;
		this->name = name;
		this->address = address;
		next = NULL;
		previous = NULL;
	}
	void setNext(Node* next)
	{
		this->next = next;
	}
	void setName(string name)
	{
		this->name = name;
	}
	void setAddress(string address)
	{
		this->address = address;
	}
	Node* getNext()
	{
		return next;
	}
	void setPrevious(Node* previous)
	{
		this->previous = previous;
	}
	Node* getPrevious()
	{
		return previous;
	}
	void setData(int data)
	{
		this->data = data;
	}
	int getData()
	{
		return data;
	}
	string getName()
	{
		return name;
	}
	string getAddress()
	{
		return address;
	}
	void display(Node* ptr)
	{
		cout << "Name :" <<&ptr->getName();
		cout << "Address : " << &ptr->getAddress();
	}
};


class linkedList
{
private:
	Node* head;
	Node* tail;
public:
	linkedList()
	{
		head = NULL;
		tail = NULL;
	}
	void insert(int data,string name,string address)
	{
		Node* newNode = new Node(data,name,address);
		if (head == NULL)
		{
			head = newNode;
			tail = newNode;
		}
		else
		{
			tail->setNext(newNode);
			newNode->setPrevious(tail);
			tail = newNode;
			
		}
	}
	void insertAfter(int key, int data,string name,string address)
	{
		if (search(key))
		{
				Node* newNode = new Node(data,name,address);
				Node* temp = head;
				Node* nex = temp->getNext();
				while (true)
				{
					if (temp->getData() == key)
					{
						nex->setPrevious(newNode);
						newNode->setNext(nex);
						temp->setNext(newNode);
						newNode->setPrevious(temp);
						break;
					}
					temp = temp->getNext();
					nex = nex->getNext();
				}
		}
		else
		{
			cerr << key << " does not exist \n";
		}
	}
	void insertBefore(int key, int data, string name, string address)
	{
		if (search(key))
		{
			if (head->getData() == key)
			{
				insertAtFront(data,name,address);
			}
			else
			{
				Node* newNode = new Node(data, name, address);
				Node* pre = head;
				Node* temp = pre->getNext();
				while (true)
				{
					if (temp->getData() == key)
					{
						pre->setNext(newNode);
						newNode->setPrevious(pre);
						temp->setPrevious(newNode);
						newNode->setNext(temp);
						break;
					}
					temp = temp->getNext();
					pre = pre->getNext();
				}
			}
			
		}
		else
		{
			cerr << key << " does not exist \n";
		}
	}
	bool search(int key)
	{
		if (!isEmpty())
		{
			Node* traverse = head;
			while (traverse != NULL)
			{
				if (traverse->getData() == key)
				{
					return true;
				}
				traverse = traverse->getNext();
			}
		}
		else
		{
			cout << "Empty \n";
		}
		return false;
	}
	void update(int old, int New)
	{
		if (search(old))
		{
			Node* traverse = head;
			while (traverse != NULL)
			{
				if (traverse->getData() == old)
				{
					traverse->setData(New);
					break;
				}
				traverse = traverse->getNext();
			}
		}
		else
		{
			cout << "Not found \n";
		}
	}
	void deleteNode(int key)
	{
		if (search(key))
		{
			if (head->getData() == key)
			{
				Node* temp = head;
				head = temp->getNext();
				head->setPrevious(NULL); 
				delete temp;
			}
			else
			{
				Node* previous = head;
				Node* traverse = head->getNext();
				while (traverse != NULL)
				{
					if (traverse->getData() == key && traverse == tail)
					{
						//delete it and attach tail with previous
						previous->setNext(traverse->getNext());
						tail = previous;
						tail->setNext(NULL);
						delete traverse;
						break;
					}
					else if (traverse->getData() == key)
					{
						//delete it
						previous->setNext(traverse->getNext());
						traverse->getNext()->setPrevious(previous);
						delete traverse;
						break;
					}
					else
					{
						previous = traverse;
						traverse = traverse->getNext();
					}

				}
			}

		}
		else
		{
			cout << "Not found \n";
		}
	}
	void deleteFromBegin()
	{
		head = head->getNext();
		head->setPrevious(NULL);
	}
	void deleteFromEnd()
	{
		tail = tail->getPrevious();
		tail->setNext(NULL);
	}
	void Delete()
	{
		if (max() != 0)
		{
			if (head->getData() == max())
			{
				deleteFromBegin();
			}
			else
			{
				Node* pre = head;
				Node* temp = head->getNext();
				while (temp != NULL)
				{
					if (temp->getData() == max() && temp == tail)
					{
						deleteFromEnd();
					}
					else if (temp->getData() == max())
					{
						pre->setNext(temp->getNext());
						temp->getNext()->setPrevious(pre);
						delete temp;
						break;
					}
					temp = temp->getNext();
					pre = pre->getNext();
				}
			}
			
		}
	}
	void deleteList()
	{
		head = tail = NULL;
	}
	int max()
	{
		int max = 0;
		Node* temp = head;
		while (temp != NULL)
		{
			if (temp->getData() > max)
			{
				max = temp->getData();
			}
			temp = temp->getNext();
		}
		return max;
	}
	int frequency(int key)
	{
		if (search(key))
		{
			int freq = 0;
			Node* traverse = head;
			while (traverse != NULL)
			{
				if (traverse->getData() == key)
				{
					freq++;

				}
				traverse = traverse->getNext();
			}
			return freq;
		}
		else
		{
			cout << "Not found \n";
		}
		return 0;
	}
	void insertAtFront(int data,string name,string address)
	{
		if (!isEmpty())
		{
			Node* newNode = new Node(data,name,address);
			head->setPrevious(newNode);
			newNode->setNext(head);
			head = newNode;
		}
		else
		{
			//first data
			Node* newNode = new Node(data,name,address);
			head = newNode;
			tail = newNode;
		}
	}
	void insetAtEnd(int data, string name, string address)
	{
		if (!isEmpty())
		{
			Node* newNode = new Node(data,name,address);
			tail->setNext(newNode);
			newNode->setPrevious(tail);
			tail = newNode;
		}
		else
		{
			Node* newNode = new Node(data,name,address);
			head = newNode;
			tail = newNode;
		}
	}
	bool isEmpty()
	{
		if (head == NULL)
		{
			return true;
		}
		return false;
	}
	void display()
	{
		if (!isEmpty())
		{
			Node* traverse = head;
			while (traverse != NULL)
			{
				cout << traverse->getData() <<" , " << traverse->getName() <<" , " << traverse->getAddress() <<endl;
				
				traverse = traverse->getNext();
			}
			cout << endl;
		}
		else
		{
			cout << "Empty \n";
		}

	}
	void reverseDisplay()
	{
		if (!isEmpty())
		{
			Node* traverse = tail;
			while (traverse != NULL)
			{
				
				cout << traverse->getData() << " , " << traverse->getName() << " , " << traverse->getAddress() << endl;

				traverse = traverse->getPrevious();
			}
			cout << endl;
		}
		else
		{
			cout << "Empty \n";
		}
	}

};

int main()
{
	//insertion
	linkedList list;
	list.insert(1,"Ali1","325 E DHA Lahore");
	list.insert(2, "Ali2", "325 E DHA Lahore");
	list.insert(3, "Ali3", "325 E DHA Lahore");
	list.insert(12, "Ali4", "325 E DHA Lahore");
	list.display();
	list.insertBefore(2, 50, "Ali5", "325 E DHA Lahore");
	list.display();
	list.insertAfter(1, 500, "Ali6", "325 E DHA Lahore");
	list.display();
	list.deleteFromBegin();
	list.display();
	list.deleteFromEnd();
	list.display();
	list.Delete();
	list.display();
	
	list.reverseDisplay();
	list.display();
	list.deleteList();
	list.display();
	
	system("pause");
	return 0;
}