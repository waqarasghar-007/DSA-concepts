#include <iostream>
#include <string>
using namespace std;



class Contact {
private:
	 string name;
	 string phoneNumber;
	 string email;
	 string address;

public:
	Contact()
	{
		this->name = "";
		this->phoneNumber = "";
		this->email = "";
		this->address = "";
	}
	Contact(const  string& name, const  string& phoneNumber, const  string& email, const  string& address)
		: name(name), phoneNumber(phoneNumber), email(email), address(address) {}

	 string getName() const {
		return name;
	}

	 string getPhoneNumber() const {
		return phoneNumber;
	}

	 string getEmail() const {
		return email;
	}

	 string getAddress() const {
		return address;
	}

	void setName(const  string& name) {
		this->name = name;
	}

	void setPhoneNumber(const  string& phoneNumber) {
		this->phoneNumber = phoneNumber;
	}

	void setEmail(const  string& email) {
		this->email = email;
	}

	void setAddress(const  string& address) {
		this->address = address;
	}
	void display()
	{
		cout << "Name : " << getName() << endl;
		cout << "Email : " << getEmail() << endl;
		cout << "Phone : " << getPhoneNumber() << endl;
		cout << "Address : " << getAddress() << endl;
	}
};



template <class T>
class Stack {
private:
	int top;
	T* ptr;
	int size;

public:
	Stack() {
		size = 3;
		ptr = new T[size];
		top = -1;
	}

	Stack(int size) {
		this->size = size;
		ptr = new T[size];
		top = -1;
	}

	void push(const T& data) {
		if (!isFull()) {
			if (isEmpty()) {
				top = 0;
				ptr[top] = data;
				top++;
			}
			else {
				ptr[top] = data;
				top++;
			}
		}
		else {
			// regrow stack
			T* temp;
			temp = new T[size * 2];
			for (int i = 0; i < top; i++) {
				temp[i] = ptr[i];
			}
			delete[] ptr;
			ptr = temp;
			size *= 2;
			push(data);
		}
	}

	bool isEmpty() const {
		return top == -1;
	}

	bool isFull() const {
		return top == size;
	}

	T pop() {
		T temp;
		if (!isEmpty()) {
			temp = ptr[top - 1];
			top--;
			return temp;
		}
		else {
			cout << "Empty stack" << endl;
			return T();
		}
	}

	T peek() const {
		if (!isEmpty()) {
			return ptr[top - 1];
		}
		else {
			cout << "Empty stack" << endl;
			return T();
		}
	}

	void display() const {
		if (!isEmpty()) {
			cout << "Total Entries: " << top << endl;
			for (int i = 0; i < top; i++) {
				cout << ptr[i] << ",";
			}
			cout << endl;
		}
		else {
			cout << "Empty stack" << endl;
		}
	}
};

template <class T>
class Queue
{
private:
	int front;
	T* ptr;
	int rear;
	int size;

public:
	Queue()
	{
		size = 3;
		ptr = new T[size];
		front = rear = -1;
	}

	Queue(int size)
	{
		this->size = size;
		ptr = new T[size];
		front = rear = -1;
	}

	void Enqueue(T data)
	{
		if (!isFull())
		{
			if (isEmpty())
			{
				front = rear = 0;
				ptr[rear] = data;
				rear++;
			}
			else
			{
				ptr[rear] = data;
				rear++;
			}
		}
		else
		{
			//regrow queue
			T* temp;
			temp = new T[size * 2];
			for (int i = 0; i < rear; i++)
			{
				temp[i] = ptr[i];
			}
			delete[] ptr;
			ptr = temp;
			size *= 2;
			Enqueue(data);
		}
	}

	bool isEmpty()
	{
		if (front == -1 && rear == -1)
		{
			return true;
		}
		return false;
	}

	bool isFull()
	{
		if (rear == size)
		{
			return true;
		}
		return false;
	}

	T Dequeue()
	{
		T temp ;
		if (!isEmpty())
		{
			temp = ptr[front];
			for (int i = 0; i < rear; i++)
			{
				ptr[i] = ptr[i + 1];
			}
			rear--;
			return temp;
		}
		else
		{
			cout << "Empty Queue \n";
		}
	}

	T peek()
	{
		T temp;
		if (!isEmpty())
		{
			temp = ptr[front];
			return temp;
		}
		else
		{
			cout << "Empty Queue \n";
		}
	}

	void display()
	{
		if (!isEmpty())
		{
			cout << "Total Entries: " << rear << endl;
			for (int i = 0; i < rear; i++)
			{
				cout << ptr[i] << ",";
			}
		}
		else
		{
			cout << "Empty Queue \n";
		}
	}
};

class Node {
private:
	Node* next;
	Node* previous;
	Contact data;

public:
	Node() {
		next = NULL;
		previous = NULL;
	}

	Node(const Contact& data) {
		this->data = data;
		next = NULL;
		previous = NULL;
	}

	void setNext(Node* next) {
		this->next = next;
	}

	Node* getNext() {
		return next;
	}

	void setPrevious(Node* previous) {
		this->previous = previous;
	}

	Node* getPrevious() {
		return previous;
	}

	void setData(const Contact& data) {
		this->data = data;
	}

	Contact getData() {
		return data;
	}
};

class linkedList {
private:
	Node* head;
	Node* tail;

public:
	linkedList() {
		head = NULL;
		tail = NULL;
	}

	void insert(const Contact& data) {
		Node* newNode = new Node(data);
		if (head == NULL) {
			head = newNode;
			tail = newNode;
		}
		else {
			tail->setNext(newNode);
			newNode->setPrevious(tail);
			tail = newNode;
		}
	}

	bool search(const Contact& key) {
		if (!isEmpty()) {
			Node* traverse = head;
			while (traverse != NULL) {
				if (traverse->getData().getName() == key.getName() &&
					traverse->getData().getPhoneNumber() == key.getPhoneNumber() &&
					traverse->getData().getEmail() == key.getEmail() &&
					traverse->getData().getAddress() == key.getAddress()) {
					return true;
				}
				traverse = traverse->getNext();
			}
		}
		else {
			cout << "Empty \n";
		}
		return false;
	}

	void update(const Contact& oldContact, const Contact& newContact) {
		if (search(oldContact)) {
			Node* traverse = head;
			while (traverse != NULL) {
				if (traverse->getData().getName() == oldContact.getName() &&
					traverse->getData().getPhoneNumber() == oldContact.getPhoneNumber() &&
					traverse->getData().getEmail() == oldContact.getEmail() &&
					traverse->getData().getAddress() == oldContact.getAddress()) {
					traverse->setData(newContact);
					break;
				}
				traverse = traverse->getNext();
			}
		}
		else {
			cout << "Not found \n";
		}
	}

	void deleteNode(const Contact& key) {
		if (search(key)) {
			if (head->getData().getName() == key.getName() &&
				head->getData().getPhoneNumber() == key.getPhoneNumber() &&
				head->getData().getEmail() == key.getEmail() &&
				head->getData().getAddress() == key.getAddress()) {
				Node* temp = head;
				head = temp->getNext();
				head->setPrevious(NULL);
				delete temp;
			}
			else {
				Node* previous = head;
				Node* traverse = head->getNext();
				while (traverse != NULL) {
					if (traverse->getData().getName() == key.getName() &&
						traverse->getData().getPhoneNumber() == key.getPhoneNumber() &&
						traverse->getData().getEmail() == key.getEmail() &&
						traverse->getData().getAddress() == key.getAddress() &&
						traverse == tail) {
						previous->setNext(traverse->getNext());
						tail = previous;
						tail->setNext(NULL);
						delete traverse;
						break;
					}
					else if (traverse->getData().getName() == key.getName() &&
						traverse->getData().getPhoneNumber() == key.getPhoneNumber() &&
						traverse->getData().getEmail() == key.getEmail() &&
						traverse->getData().getAddress() == key.getAddress()) {
						previous->setNext(traverse->getNext());
						traverse->getNext()->setPrevious(previous);
						delete traverse;
						break;
					}
					else {
						previous = traverse;
						traverse = traverse->getNext();
					}
				}
			}
		}
		else {
			cout << "Not found \n";
		}
	}

	int frequency(const Contact& key) {
		if (search(key)) {
			int freq = 0;
			Node* traverse = head;
			while (traverse != NULL) {
				if (traverse->getData().getName() == key.getName() &&
					traverse->getData().getPhoneNumber() == key.getPhoneNumber() &&
					traverse->getData().getEmail() == key.getEmail() &&
					traverse->getData().getAddress() == key.getAddress()) {
					freq++;
				}
				traverse = traverse->getNext();
			}
			return freq;
		}
		else {
			cout << "Not found \n";
		}
		return 0;
	}

	void insertAtFront(const Contact& data) {
		if (!isEmpty()) {
			Node* newNode = new Node(data);
			head->setPrevious(newNode);
			newNode->setNext(head);
			head = newNode;
		}
		else {
			Node* newNode = new Node(data);
			head = newNode;
			tail = newNode;
		}
	}

	void insetAtEnd(const Contact& data) {
		if (!isEmpty()) {
			Node* newNode = new Node(data);
			tail->setNext(newNode);
			newNode->setPrevious(tail);
			tail = newNode;
		}
		else {
			Node* newNode = new Node(data);
			head = newNode;
			tail = newNode;
		}
	}

	void insertAfter(const Contact& key, const Contact& data) {
		if (!isEmpty()) {
			if (search(key)) {
				Node* newNode = new Node(data);
				Node* traverse = head;
				while (traverse != NULL) {
					if (traverse->getData().getName() == key.getName() &&
						traverse->getData().getPhoneNumber() == key.getPhoneNumber() &&
						traverse->getData().getEmail() == key.getEmail() &&
						traverse->getData().getAddress() == key.getAddress() &&
						traverse == tail) {
						insetAtEnd(data);
						break;
					}
					else if (traverse->getData().getName() == key.getName() &&
						traverse->getData().getPhoneNumber() == key.getPhoneNumber() &&
						traverse->getData().getEmail() == key.getEmail() &&
						traverse->getData().getAddress() == key.getAddress()) {
						traverse->getNext()->setPrevious(newNode);
						newNode->setNext(traverse->getNext());
						traverse->setNext(newNode);
						newNode->setPrevious(traverse);
						break;
					}
					else {
						traverse = traverse->getNext();
					}
				}
			}
			else {
				cout << key.getName() << " does not exist inside \n";
			}
		}
		else {
			cout << key.getName() << " does not exist \n";
		}
	}

	bool isEmpty() {
		if (head == NULL) {
			return true;
		}
		return false;
	}

	void display() {
		if (!isEmpty()) {
			Node* traverse = head;
			while (traverse != NULL) {
				cout << "Name: " << traverse->getData().getName() << endl;
				cout << "Phone Number: " << traverse->getData().getPhoneNumber() << endl;
				cout << "Email: " << traverse->getData().getEmail() << endl;
				cout << "Address: " << traverse->getData().getAddress() << endl;
				cout << endl;
				traverse = traverse->getNext();
			}
			cout << endl;
		}
		else {
			cout << "Empty \n";
		}
	}

	Node* getHead() {
		return head;
	}

	Node* getTail()
	{
		return tail;
	}
};

class Action {
private:
	Contact contact;
	string type;
	Contact previousState;

public:
	Action() {
		// Default constructor
		contact = Contact();
		type = "";
		previousState = Contact();
	}
	Action(Contact contact, string type, Contact previousState) {
		this->contact = contact;
		this->type = type;
		this->previousState = previousState;
	}

	Contact getContact() {
		return contact;
	}

	string getType() {
		return type;
	}

	Contact getPreviousState() {
		return previousState;
	}
};

class CallEntry {
private:
	Contact contact;
	int callDuration;
	string callType;
	string callDate;

public:
	CallEntry() {
		contact = Contact();
		callDuration = 0;
		callType = "";
		callDate = "";
	}
	CallEntry(Contact contact, int callDuration, string callType, string callDate) {
		this->contact = contact;
		this->callDuration = callDuration;
		this->callType = callType;
		this->callDate = callDate;
	}

	Contact getContact() {
		return contact;
	}

	int getCallDuration() {
		return callDuration;
	}

	string getCallType() {
		return callType;
	}

	string getCallDate() {
		return callDate;
	}
};

//template node class for the implementation of bst
template <class T>
class node
{
private:
	T data;
	node<T>* right;
	node<T>* left;

public:
	node()
	{
		data = T();
		left = right = nullptr;
	}

	node(T data)
	{
		this->data = data;
		left = right = nullptr;
	}

	void setData(T data)
	{
		this->data = data;
	}

	void setRight(node<T>* right)
	{
		this->right = right;
	}

	void setLeft(node<T>* left)
	{
		this->left = left;
	}

	T getData()
	{
		return data;
	}

	node<T>* getRight()
	{
		return right;
	}

	node<T>* getLeft()
	{
		return left;
	}
};

template <class T>
class BST
{
private:
	node<T>* root;

public:
	BST()
	{
		root = nullptr;
	}

	void insert(T data)
	{
		node<T>* newNode = new node<T>(data);

		if (root == nullptr)
		{
			root = newNode;
		}
		else
		{
			node<T>* current = root;
			node<T>* parent = nullptr;

			while (current != nullptr)
			{
				parent = current;

				if (data < current->getData())
				{
					current = current->getLeft();
				}
				else
				{
					current = current->getRight();
				}
			}

			if (data < parent->getData())
			{
				parent->setLeft(newNode);
			}
			else
			{
				parent->setRight(newNode);
			}
		}
	}

	bool search(T data)
	{
		return searchRecursive(root, data);
	}

	void remove(T data)
	{
		root = removeRecursive(root, data);
	}

	void displayInorder()
	{
		inorderTraversal(root);
	}

private:
	bool searchRecursive(node<T>* node, T data)
	{
		if (node == nullptr)
		{
			return false;
		}

		if (node->getData() == data)
		{
			return true;
		}

		if (data < node->getData())
		{
			return searchRecursive(node->getLeft(), data);
		}
		else
		{
			return searchRecursive(node->getRight(), data);
		}
	}

	node<T>* removeRecursive(node<T>* node1, T data)
	{
		if (node1 == nullptr)
		{
			return nullptr;
		}

		if (data < node->getData())
		{
			node->setLeft(removeRecursive(node1->getLeft(), data));
		}
		else if (data > node1->getData())
		{
			node1->setRight(removeRecursive(node1->getRight(), data));
		}
		else
		{
			if (node1->getLeft() == nullptr && node1->getRight() == nullptr)
			{
				delete node1;
				return nullptr;
			}
			else if (node1->getLeft() == nullptr)
			{
				node<T>* temp = node1->getRight();
				delete node1;
				return temp;
			}
			else if (node1->getRight() == nullptr)
			{
				node<T>* temp = node1->getLeft();
				delete node1;
				return temp;
			}
			else
			{
				node<T>* successor = findMin(node1->getRight());
				node1->setData(successor->getData());
				node1->setRight(removeRecursive(node1->getRight(), successor->getData()));
			}
		}

		return node1;
	}

	node<T>* findMin(node<T>* node1)
	{
		if (node1 == nullptr)
		{
			return nullptr;
		}

		while (node1->getLeft() != nullptr)
		{
			node1 = node1->getLeft();
		}

		return node1;
	}

	void inorderTraversal(node<T>* node1)
	{
		if (node1 != nullptr)
		{
			inorderTraversal(node1->getLeft());
			cout << node1->getData() << " ";
			inorderTraversal(node1->getRight());
		}
	}
};


class ContactManagementSystem {
private:
	//BST<Contact> contacts;
	linkedList contacts; 
	Stack<Action> undoStack;
	Stack<Action> redoStack;
	Queue<CallEntry> callHistory;
public:
	/*
	void addContact(T contact) {
		contacts.insert(contact);
	}

	void deleteContact(T contact) {
		contacts.remove(contact);
	}
	*/
	void addContact(Contact contact) {
		contacts.insert(contact);
	}

	void deleteContact(Contact contact) {
		contacts.deleteNode(contact);
	}

	void modifyContact(Contact contact) {
		Node* currentNode = contacts.getHead();
		while (currentNode != contacts.getTail()) {
			if (currentNode->getData().getName() == contact.getName()) {
				Action action(currentNode->getData(), "MODIFY", currentNode->getData());
				currentNode->getData().setPhoneNumber(contact.getPhoneNumber());
				currentNode->getData().setEmail(contact.getEmail());
				currentNode->getData().setAddress(contact.getAddress());
				undoStack.push(action);
				return; 
			}
			currentNode = currentNode->getNext();
		}
	}

	linkedList searchContacts(string criteria) {
		linkedList searchResults;

		Node* currentNode = contacts.getHead();

		while (currentNode != nullptr) {
			if (currentNode->getData().getName() == criteria || currentNode->getData().getPhoneNumber() == criteria || currentNode->getData().getEmail() == criteria) {
				searchResults.insert(currentNode->getData());
			}

			currentNode = currentNode->getNext();
		}

		return searchResults;
	}

	void undo() {
		if (!undoStack.isEmpty()) {
			Action action = undoStack.peek();
			undoStack.pop();

			Contact contact = action.getPreviousState();

			
			if (action.getType() == "ADD") {
				contacts.deleteNode(contact);
			}
			else if (action.getType() == "MODIFY") {
				modifyContact(contact);
			}
			else if (action.getType() == "DELETE") {
				contacts.insert(contact);
			}

			redoStack.push(action);
		}
	}

	void redo() {
		if (!redoStack.isEmpty()) {
			Action action = redoStack.peek();
			redoStack.pop();

			Contact contact = action.getContact();

			
			if (action.getType() == "ADD") {
				contacts.insert(contact);
			}
			else if (action.getType() == "MODIFY") {
				modifyContact(contact);
			}
			else if (action.getType() == "DELETE") {
				contacts.deleteNode(contact);
			}

			
			undoStack.push(action);
		}
	}

	void enqueueCall(CallEntry call) {
		callHistory.Enqueue(call);
	}

	CallEntry dequeueCall() {
		CallEntry call = callHistory.peek();
		callHistory.Dequeue();
		return call;
	}

	
};

int main()
{
	ContactManagementSystem cms;
	Contact contact1("John Doe", "1234567890", "john.doe@example.com", "123 Main St");
	cms.addContact(contact1);

	string sear = "John Doe";
	cout << "Searching for : " << sear << endl;
	
	linkedList searchResults = cms.searchContacts(sear);
	cout << "Results \n";
	searchResults.display();
	
	contact1.setPhoneNumber("9876543210");
	cms.modifyContact(contact1);

	cout << "\n Modified Contact : \n ";
	
	searchResults = cms.searchContacts("John Doe");

	searchResults.display();
	cms.undo();

	cout << "\n After Undo \n";
	searchResults = cms.searchContacts("John Doe");

	searchResults.display();

	
	CallEntry call(contact1, 60, "OUTGOING", "2023-07-02");
	cms.enqueueCall(call);


	system("pause");
	return 0;
}