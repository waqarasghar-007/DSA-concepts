#include <iostream>
using namespace std;

class CPU
{
protected:
	string companyName;
	int speed;
	float price;
public:
	CPU()
	{
		companyName = nullptr;
		speed = -1;
		price = 0.0f;
	}
	void setCompanyName(string companyName)
	{
		this->companyName = companyName;
	}
	void setSpeed(int speed)
	{
		this->speed = speed;
	}
	void setPrice(float price)
	{
		this->price = price;
	}

	int getSpeed()
	{
		return speed;
	}
	float getPrice()
	{
		return price;
	}
	string getCompanyName()
	{
		return companyName;
	}
};

class monitor
{
protected:
	string companyName;
	int size;
	float price;
public:
	monitor()
	{
		companyName = nullptr;
		size = -1;
		price = 0.0f;
	}
	void setCompanyName(string companyName)
	{
		this->companyName = companyName;
	}
	void setSpeed(int size)
	{
		this->size = size;
	}
	void setPrice(float price)
	{
		this->price = price;
	}

	int getSize()
	{
		return size;
	}
	float getPrice()
	{
		return price;
	}
	string getCompanyName()
	{
		return companyName;
	}
};

class keyboard
{
protected:
	string companyName;
	int numberOfKeys;
	float price;
public:
	keyboard()
	{
		companyName = nullptr;
		numberOfKeys = -1;
		price = 0.0f;
	}
	void setCompanyName(string companyName)
	{
		this->companyName = companyName;
	}
	void setSpeed(int numberOfKeys)
	{
		this->numberOfKeys = numberOfKeys;
	}
	void setPrice(float price)
	{
		this->price = price;
	}

	int getNumberOfKeys()
	{
		return numberOfKeys;
	}
	float getPrice()
	{
		return price;
	}
	string getCompanyName()
	{
		return companyName;
	}
};
class computerSystem
{

};
