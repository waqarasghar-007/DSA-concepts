#include <iostream>
using namespace std;
class Node
{
private:
	int data;
	Node* right;
	Node* left;
public:
	Node()
	{
		data = 0;
		left = right = NULL;
	}
	Node(int data)
	{
		this->data = data;
		left = right = NULL;
	}
	void setData(int data)
	{
		this->data = data;
	}
	void setRight(Node *right)
	{
		this->right = right;
	}
	void setLeft(Node* left)
	{
		this->left = left;
	}
	int getData()
	{
		return data;
	}
	Node* getRight()
	{
		return right;
	}
	Node* getLeft()
	{
		return left;
	}
};

class BST
{
private:
	Node* root;
public:
	BST()
	{
		root = NULL;
	}
	void insert(int data)
	{
		Node* N = new Node(data);

		if (root == NULL)
		{
			root = N;
		}
		else
		{
			Node *temp = root;
			while (true)
			{
				if (temp->getData() < data)
				{
					if (temp->getRight() == NULL)
					{
						temp->setRight(N);

						break;
					}
					else
					{
						temp = temp->getRight();
					}
				}
				else if (temp->getData() > data)
				{
					if (temp->getLeft() == NULL)
					{
						temp->setLeft(N);

						break;
					}
					else
					{
						temp = temp->getLeft();
					}
				}
			}
		}
	}
	void display(int select)
	{
		if (root == NULL)
		{
			cout << "Empty tree \n";
		}
		else
		{
			if (select == 1)
			{
				inorder(root);
			}

		}
	}
	void inorder(Node *temp)
	{
		if (temp == NULL)
			return;
		inorder(temp->getLeft());
		cout << temp->getData() << " , ";
		inorder(temp->getRight());
	}
	Node* findMin(Node* temp)
	{
		if (temp == NULL)
		{
			return temp;
		}
		else
		{
			while (temp->getLeft() != NULL)
			{
				temp = temp->getLeft();
			}

			return temp;
		}
	}
	Node* findMax(Node* temp)
	{
		if (temp == NULL)
		{
			return temp;
		}
		else
		{
			while (temp->getRight() != NULL)
			{
				temp = temp->getRight();
			}

			return temp;
		}
	}
	Node* getRoot()
	{
		return root;
	}
	int findSuccessor(int key,Node* root){
		if (root == NULL)
			return 0;
		else
		{
			Node* pre = NULL;
			Node* temp = root;
			while (true)
			{

				if (key > temp->getData())
				{
					//right
					pre = temp;
					temp = temp->getRight();
				}
				else if (key < temp->getData())
				{
					//left
					pre = temp;
					temp = temp->getLeft();
				}
				else if (key == temp->getData())
				{
					int num = pre->getData();
					return num;
				}
			}
			

		}
	}
	int findPredecessor(int key,Node* root){
		if (root == NULL)
			return 0;
		else
		{
			Node* pre = NULL;
			Node* temp = root;
			while (true)
			{

				if (key > temp->getData())
				{
					//right
					pre = temp;
					temp = temp->getRight();
				}
				else if (key < temp->getData())
				{
					//left
					pre = temp;
					temp = temp->getLeft();
				}
				else if (key == temp->getData())
				{
					if (temp->getRight() == NULL)
					{
						return temp->getLeft()->getData();
					}
					else if (temp->getLeft() == NULL)
					{
						return temp->getRight()->getData();
					}
					else
					{
						return findMin(temp->getLeft())->getData();
						       
					}
					
					
				}
			}


		}
	}

	

};

int main()
{
	BST t1;
	t1.insert(6);
	t1.insert(3);
	t1.insert(9);
	t1.insert(1);
	t1.insert(4);
	t1.insert(12);
	cout << "Given Tree is : "; 
	t1.display(1);
	cout << endl;
	//Find the minimum value in the above BST.
	
	cout << "Minimum number in the above tree is : " << t1.findMin(t1.getRoot())->getData() << endl;
	
	//Find the maximum value in the above BST.
	cout << "Maximum number in the above tree is : " << t1.findMax(t1.getRoot())->getData() << endl;
	//Find the successor of the value 4 in the above BST.
	int num = 4;
	cout << "Successor of the " << num << " in the given tree is : " << t1.findSuccessor(num, t1.getRoot()) <<endl;
	//Find the predecessor of the value 9 in the above BST.
	int num2 = 9;
	cout << "Predecessor of the " << num2 << " in the given tree is : " << t1.findPredecessor(num2, t1.getRoot()) <<endl;
	


	system("pause");
	return 0;
}